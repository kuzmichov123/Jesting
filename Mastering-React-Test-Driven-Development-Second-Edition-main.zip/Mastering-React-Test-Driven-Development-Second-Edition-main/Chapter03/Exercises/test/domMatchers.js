import { toContainText } from "./matchers/toContainText";

expect.extend({
  toContainText,
});
