global.fetch = () => Promise.resolve({});
