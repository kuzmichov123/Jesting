export const blankCustomer = {
  firstName: "",
  lastName: "",
  phoneNumber: "",
};
