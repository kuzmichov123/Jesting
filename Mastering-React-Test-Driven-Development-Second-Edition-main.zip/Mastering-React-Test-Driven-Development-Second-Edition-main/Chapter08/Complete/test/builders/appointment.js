export const blankAppointment = {
  service: "",
  stylist: "",
  startsAt: null,
};
